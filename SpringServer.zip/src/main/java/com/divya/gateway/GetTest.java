package com.divya.gateway;

/**
 * Created by divyashreenair on 28/3/16.
 */
public class GetTest {
    private String testString;
    private String title;
    private String task;

    public String getTestString() {
        return testString;
    }

    public void setTestString(String testString) {
        this.testString = testString;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getTask() {
        return task;
    }

    public void setTask(String task) {
        this.task = task;
    }
}
