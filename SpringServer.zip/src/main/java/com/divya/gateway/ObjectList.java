package com.divya.gateway;

import java.util.ArrayList;

/**
 * Created by divyashreenair on 28/3/16.
 */
public class ObjectList {
    GetList getList;
    public GetList getName() {
        return getList;
    }

    public void setName(GetList name) {
        this.getList = name;
    }
}
