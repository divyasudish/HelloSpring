package com.divya.gateway;

import java.util.ArrayList;

/**
 * Created by divyashreenair on 28/3/16.
 */
public class GetList {

    ArrayList<Test> list2 = new ArrayList<>();
    ArrayList<Test> list1 = new ArrayList<>();

    public ArrayList<Test> getList1() {
        return list1;
    }

    public void setList1(ArrayList<Test> list1) {
        this.list1 = list1;
    }

    public ArrayList<Test> getList2() {
        return list2;
    }

    public void setList2(ArrayList<Test> list2) {
        this.list2 = list2;
    }
}
